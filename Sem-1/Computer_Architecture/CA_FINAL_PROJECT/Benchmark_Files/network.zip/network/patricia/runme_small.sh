#!/bin/sh
patricia small.udp > output_small.txt
