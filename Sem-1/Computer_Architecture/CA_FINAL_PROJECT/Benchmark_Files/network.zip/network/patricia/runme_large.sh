#!/bin/sh
patricia large.udp > output_large.txt
