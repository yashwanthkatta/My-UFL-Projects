#!/bin/sh
sha input_large.asc > output_large.txt
