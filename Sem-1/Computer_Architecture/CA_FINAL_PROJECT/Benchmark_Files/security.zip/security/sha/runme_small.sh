#!/bin/sh
sha input_small.asc > output_small.txt
